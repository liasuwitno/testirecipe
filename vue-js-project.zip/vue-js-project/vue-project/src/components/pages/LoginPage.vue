<template>
    <web-login></web-login>
</template>

<script setup>
    import WebLogin from "../auth/WebLogin.vue"
</script>