<template>
    <main>
        <div class="container-md my-5 py-5">
            <div class="row my-4">
                <div class="col-12 col-sm-2"></div>
                <recipe-detail></recipe-detail>
                <div class="col-12 col-sm-2"></div>
            </div>
        </div>
    </main>
</template>

<script setup>
import RecipeDetail from '../detail/RecipeDetail.vue';
</script>