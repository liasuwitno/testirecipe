<template>
  <ul class="list-group">
    <li class="list-group-item">
      <div
        class="d-flex flex-sm-row flex-column justify-content-between align-items-sm-center"
      >
        <div class="mb-3 mb-sm-0">
          <p class="my-0 fs-4 fw-semibold">My Recipe</p>
          <p class="my-0 text-secondary">Add your original recipe here</p>
        </div>
        <router-link to="/new-recipe">
          <base-button class="btn add-btn px-3 py-2 rounded-pill">
            <i class="fa-solid fa-circle-plus pe-2"></i>Add Recipe
          </base-button>
        </router-link>
      </div>
    </li>
    <li class="list-group-item">
      <p class="mt-2 mb-4 fs-5 fw-semibold">Recipe</p>
      <div class="row">
        <user-recipe-card
          v-for="recipe in recipes"
          :key="recipe.id"
          :recipe="recipe"
          :buttonName="['Delete', 'Edit']"
          @btnRemove="deleteRecipe(recipe.id)"
          @btnEdit="editRecipe(recipe.id)"
        >
          <p>{{ new Date(recipe.createdAt).toDateString() }}</p>
        </user-recipe-card>
      </div>
    </li>
  </ul>
</template>

<script setup>
import BaseButton from "../ui/BaseButton.vue";
import { RouterLink, useRoute } from "vue-router";
import { computed, onMounted, ref } from "vue";
import { useStore } from "vuex";
import UserRecipeCard from "./UserRecipeCard.vue";
import {useRouter} from "vue-router";


const router = useRouter()
const store = useStore();

const recipeListStatus = ref(false);
// const recipes = ref();

console.log({ recipes: store.state.recipe.recipes });

// onMounted(async () => {
//   try {
//     await store.dispatch("recipe/getRecipeData");
//     recipeListStatus.value = true;

//     const userId = store.state.auth.userLogin.userId;
//     recipes.value = store.state.recipe.recipes.filter(
//       (recipe) => recipe.userId === userId
//     );
//   } catch (error) {
//     console.log(error);
//   }
// });

const recipes = computed(() => {
  const allRecipe = store.state.recipe.recipes;
  const userId = store.state.auth.userLogin.userId;
  return allRecipe.filter((recipe) => recipe.userId === userId);
});

const deleteRecipe = async (id) => {
  await store.dispatch("recipe/deleteRecipe", id);
};
const editRecipe = (id) => {
  router.push({name: "editRecipePage", params: {id}});
};
</script>

